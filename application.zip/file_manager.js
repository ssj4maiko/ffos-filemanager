'use strict';

var FileManager = (function(){
	function FileManager(){
		var fm = this;
		fm.storage = navigator.getDeviceStorage('sdcard');

		//fm.storage.addEventListener('change', deviceStorageChangeHandler);
		//fm.details.dsEventListener = deviceStorageChangeHandler;


		var availreq = fm.storage.available();
		availreq.onsuccess = function(e) {
			switch (e.target.result) {
				case 'available':
				  changeState(fm, 'MediaDB.READY');
				  alert('o cartão');
				  scan(fm); // Start scanning as soon as we're ready
				  break;
				case 'unavailable':
				  changeState(fm,' MediaDB.NOCARD');
				  alert('Sem cartão');
				  break;
				case 'shared':
				  changeState(fm, 'MediaDB.UNMOUNTED');
				  alert('Desmontado');
				  break;
			}
		}

		function changeState(lefm,teste){
			//alert(teste);
		}
		alert(fm.storage);
	}
	function scan(fm){
      var cursor = fm.storage.enumerate(fm.directory);
      document.write(cursor);
	}

	return FileManager;
}());

var fm = new FileManager();